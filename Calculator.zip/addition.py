Anumber1 = "0.0"
Anumber2 = "0.0"

Anumber1 = float(input("What is number 1? ")) 
Anumber2 = float(input("What is number 2? "))
Aanswer = Anumber1 + Anumber2
print(str(Anumber1) + " added to " + str(Anumber2) + ' = ' + str(Aanswer))
