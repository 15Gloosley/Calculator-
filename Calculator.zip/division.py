Bnumber1 = "0.0"
Bnumber2 = "0.0"

Bnumber1 = float(input("What is number 1?"))
Bnumber2 = float(input("What is number 2?"))
Banswer = Bnumber1 / Bnumber2
print(str(Bnumber1) + " divided by " + str(Bnumber2) + ' = ' + str(Banswer))