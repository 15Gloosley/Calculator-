while True:
  print("""What would you like to do? You could pick from
  1) Addition
  2) Division
  3) Multiplication
  4) Powers
  5) Pythagoras' Theorem
  6) Subtraction""")
  option = str(input("Type your choice, please type without any capital letters - "))

  if option == str("1"):
    import addition
  
  if option == str("2"):
    import division

  if option == str("3"):
    import multiplication

  if option == str("4"):
    import powers
  
  if option == str("5"):
    import pythagorastheorem

  if option == str("6"):
    import subtraction
  
  while True:
    answer = input('Run again? (y/n): ')
    if answer in ('y', 'n'):
       break
       print ("Invalid input.")
if answer == 'y':
  pass
else:
  print ('Goodbye')
