number1 = "0.0"
number2 = "0.0"

number1 = float(input("What is number 1?"))
number2 = float(input("What is number 2?"))
answer = number1 * number2
print(str(number1) + " times " + str(number2) + ' = ' + str(answer))