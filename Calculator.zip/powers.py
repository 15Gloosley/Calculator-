n1 = "0.0"
p1 = "0.0"

n1 = float(input("What is number 1? "))
p1 = float(input("What is the power? "))
answer = n1 ** p1
print(str(n1) + " to the power of " + str(p1) + ' = ' + str(answer))