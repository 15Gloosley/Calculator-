n1 = "0.0"
n2 = "0.0"

n1 = float(input("What is your first Number?"))
n2 = float(input("What is your second number?"))
answer = n1 - n2
print(str(n1) + " - " + str(n2) + ' = ' + str(answer))